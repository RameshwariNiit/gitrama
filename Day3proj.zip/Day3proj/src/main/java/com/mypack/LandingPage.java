package com.mypack;
import javax.management.modelmbean.ModelMBeanAttributeInfo;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class LandingPage 
{
	@RequestMapping("/register")
	public ModelAndView RegisterCode()
	{
		ModelAndView rg = new ModelAndView("Register");
		return rg;
	}
	@RequestMapping("/login")
	public ModelAndView LoginCode()
	{
		ModelAndView lo = new ModelAndView("Login");
		return lo;
	}
	
	@RequestMapping("/registerdata")
	public ModelAndView RegisterCode(@RequestParam (value="una",required=false,defaultValue="") String una)
	{	
			ModelAndView mv = new ModelAndView("registerinformation");
	
			
			
				return mv;
	}

	@RequestMapping("/logindata")
	
	public ModelAndView ValidationCode(

		@RequestParam(value = "uname", required = false, defaultValue = "World") String uname,
		@RequestParam(value="pass",required=false,defaultValue="")String pass)
	{
		 
		String user="NIIT";
		String password="NIIT";
		ModelAndView mv=null;
		if(user.equals(uname)&&password.equals(pass))
		{
			 mv = new ModelAndView("success");
		//	mv.addObject("success",msg);
			mv.addObject("name",uname);
		
		}
			
		return mv;
	}
	
		@RequestMapping("/Product")
		public ModelAndView Products(@RequestParam(value="name", required=false,defaultValue="") String name)
		{
			ModelAndView prod=null;
			
			if("img1".equals(name))
			{
				prod = new ModelAndView("Products");
				prod.addObject("Pid","P001");
				prod.addObject("Pname","Java");
				prod.addObject("Description","core java 45 days");
				prod.addObject("Price","4500");
			}
			if("img2".equals(name))
			{
				prod = new ModelAndView("Products");
				prod.addObject("Pid","P002");
				prod.addObject("Pname","Oracle");
				prod.addObject("Description","Oracle it is Technology For backend");
				prod.addObject("Price","10000");
			}
			if("img3".equals(name))
			{
				prod = new ModelAndView("Products");
				prod.addObject("Pid","P003");
				prod.addObject("Pname","DTProgram");
				prod.addObject("Description","Deveops on Java");
				prod.addObject("Price","60000");
			}
			
			return prod;
		}
		
		@RequestMapping("/AllProduct")
		public ModelAndView AllProductCode()
		{
			ModelAndView allprod = new ModelAndView("AllProductsInfo");
			return allprod;
		}

}
