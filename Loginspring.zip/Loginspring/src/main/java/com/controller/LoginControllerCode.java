package com.controller;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class LoginControllerCode 
{
	//String msg="welcome to login page";
	@RequestMapping("/login")
	
public ModelAndView ValidationCode(

		@RequestParam(value = "uname", required = false, defaultValue = "World") String uname,
		@RequestParam(value="pass",required=false,defaultValue="")String pass)
{
		 
		String user="NIIT";
		String password="NIIT";
		ModelAndView mv=null;
		if(user.equals(uname)&&password.equals(pass))
		{
			 mv = new ModelAndView("success");
		//	mv.addObject("success",msg);
			mv.addObject("name",uname);
		
		}
			
		return mv;
		

	

}
}